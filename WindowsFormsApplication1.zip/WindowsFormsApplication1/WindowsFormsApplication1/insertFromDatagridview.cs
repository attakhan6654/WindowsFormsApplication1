﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class insertFromDatagridview : Form
    {
        public insertFromDatagridview()
        {
            InitializeComponent();
        }
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True");
        DataClasses1DataContext db = new DataClasses1DataContext();
        private void Insertinsqltable_Click(object sender, EventArgs e)
        {
            int cid = 0; string cname = "", caddress = "";double cphone =0 ;
            for (int i = 0; i < dataGridView1.Rows.Count-1; i++) {

                cid = Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value.ToString());
                cname = dataGridView1.Rows[i].Cells[1].Value.ToString();
                caddress = dataGridView1.Rows[i].Cells[2].Value.ToString();
                cphone = Convert.ToDouble(dataGridView1.Rows[i].Cells[3].Value.ToString());

                var st = new MyCusTab
                {
                    CusID = cid,
                    CusName = cname,
                    CusAddress = caddress,
                    CusPhone = cphone,
                };
                db.MyCusTabs.InsertOnSubmit(st);
                db.SubmitChanges();
                dataGridView1.Rows[i].Cells[4].Value = "Success";
                loadData();
            }
        }
        void loadData() 
        {
            var st = from s in db.CashIns select s;
            dataGridView1.DataSource = st;
        }

        private void insertFromDatagridview_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'abcDataSet.MyCusTab' table. You can move, or remove it, as needed.
            this.myCusTabTableAdapter.Fill(this.abcDataSet.MyCusTab);
            dataGridView1.AutoGenerateColumns = false;
            loadData();
        }

        private void updateinsqltable_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(MessageBox.Show("Are you sure to delete ?","delete Document",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {


            }
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridView1.CurrentRow.Selected = true;
                string id = dataGridView1.Rows[e.RowIndex].Cells["CusID"].FormattedValue.ToString();


                var st = (from s in db.MyCusTabs where s.CusID == int.Parse(id) select s).First();
                db.MyCusTabs.DeleteOnSubmit(st);
                db.SubmitChanges();
                MessageBox.Show("Successfully Deleted...");
                //loaddata();
                loadData();


                //txtcusid.Text = dataGridView1.Rows[e.RowIndex].Cells["CusID"].FormattedValue.ToString();
                //txtcusname.Text = dataGridView1.Rows[e.RowIndex].Cells["CusName"].FormattedValue.ToString();
                //txtcusaddress.Text = dataGridView1.Rows[e.RowIndex].Cells["CusAddress"].FormattedValue.ToString();
                //txtcusno.Text = dataGridView1.Rows[e.RowIndex].Cells["CusPhone"].FormattedValue.ToString();
            }
        }

        //private void updateinsqltable_Click(object sender, EventArgs e)
        //{
        //    SqlCommand cmd = new SqlCommand("Select CusId,CusName,CusAddress,CusPhone from MyCusTab where CusId=@cid",con);


        //}
    }
}
