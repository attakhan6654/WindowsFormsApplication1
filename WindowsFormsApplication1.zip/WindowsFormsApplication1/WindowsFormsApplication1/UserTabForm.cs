﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class UserTabForm : Form
    {
        public UserTabForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True");
        DataClasses1DataContext db = new DataClasses1DataContext();
        private void button1_Click(object sender, EventArgs e)
        {
            CashInner ci = new CashInner();
            this.Hide();
            ci.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CashOuter co = new CashOuter();
            this.Hide();
            co.Show();
        }

        private void User_Load(object sender, EventArgs e)
        {
            ProdGV.AutoGenerateColumns = false;
            loadData();
        }

private void loadData()
{
 	var st = from s in db.MyUseTabs select s;
            dataGridView1.DataSource = st;
}

        private void bttn2_Click(object sender, EventArgs e)
        {
            ////for Insert// button code
            //var st = new MyUseTab
            //{
            //    UseFName = txtfname.Text,
            //    UseLName = txtlstname.Text,
            //    UseName = txtuname.Text,
            //    UsePassword = txtpass.Text,
            //    UsePhone = double.Parse(txtph.Text),
            //    UseCnic = txtcnic.Text,
            //    UseType = combo1.Text,


            //};
            ////db.MyCusTabs.InsertOnSubmit();
            ////db.MyUseTabs.InsertOnSubmit();
            ////db.MyUseTabs.InsertOnSubmit();
            //db.SubmitChanges();
            //MessageBox.Show("Data Inserted");
            //loaddata();
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MyUseTab values('" + txtfname.Text + "', '" + txtlstname.Text + "', '" + txtuname.Text + "', '" + txtpass.Text + "', '" + txtph.Text + "', '" + txtcnic.Text + "', '" + combo1.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Regestered Sussfully.");
            con.Close();
            
        }

        private void loaddata()
        {
            var st = from s in db.MyUseTabs select s;
            ProdGV.DataSource = st;
        }

        private void bttn4_Click(object sender, EventArgs e)
        {
            var st = (from s in db.MyUseTabs where s.UseFName == txtfname.Text select s).First();
            db.MyUseTabs.DeleteOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Successfully Deleted...");
            loaddata();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Admin_panel a_p = new Admin_panel();
            this.Hide();
            a_p.Show();
        }

        private void Insertinsqltable_Click(object sender, EventArgs e)
        {
            int ct = 0; string cgo = "", cnet = "";
            for (int i = 0; i < ProdGV.Rows.Count - 1; i++)
            {

                ct = Convert.ToInt32(ProdGV.Rows[i].Cells[0].Value.ToString());
                cgo = ProdGV.Rows[i].Cells[1].Value.ToString();
                cnet = ProdGV.Rows[i].Cells[2].Value.ToString();


                var st = new CashOut
                {
                    CashTotal = ct,
                    CashGo = cgo,
                    CashNet = cnet,
                };
                db.CashOuts.InsertOnSubmit(st);
                db.SubmitChanges();
                ProdGV.Rows[i].Cells[3].Value = "Success";
                loadData();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            this.Show();
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            NewCoutomer NC = new NewCoutomer();
            this.Hide();
            NC.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Record R = new Record();
            this.Hide();
            R.Show();
        }
    }
}
