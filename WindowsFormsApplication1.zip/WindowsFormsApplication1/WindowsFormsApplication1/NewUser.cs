﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class NewUser : Form
    {
        public NewUser()
        {
            InitializeComponent();
        }
        DataClasses1DataContext db = new DataClasses1DataContext();
        //integer validations
        private void validateTextInteger(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                if (T.Text != "-")
                {
                    int x = int.Parse(T.Text);
                }
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        //double validation
        private void validateTextDouble(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                if (T.Text != "-")
                {
                    double x = double.Parse(T.Text);

                    if (T.Text.Contains(','))
                        throw X;
                }
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        //charactor validation
        private void validateTextCharacter(object sender, EventArgs e)
        {
            TextBox T = (TextBox)sender;
            try
            {
                //Not Allowing Numbers
                char[] UnallowedCharacters = { '0', '1',
                                           '2', '3',
                                           '4', '5',
                                           '6', '7',
                                           '8', '9'};

                if (textContainsUnallowedCharacter(T.Text, UnallowedCharacters))
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
            }
            catch (Exception) { }
        }

        private bool textContainsUnallowedCharacter(string T, char[] UnallowedCharacters)
        {
            for (int i = 0; i < UnallowedCharacters.Length; i++)
                if (T.Contains(UnallowedCharacters[i]))
                    return true;

            return false;
        }

        //integer customization x<0
        private void validateTextIntegerCustomized(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                int x = int.Parse(T.Text);

                //Customizing Condition
                if (x <= 0)
                    throw X;
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }

            }
        }

        //double customization x<0
        private void validateTextDoubleCustomized(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                double x = double.Parse(T.Text);

                //Customizing Condition (Only numbers larger than or 
                //equal to zero are permitted)
                if (x < 0 || T.Text.Contains(','))
                    throw X;
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        //chractor customization
        private void validateTextCharacterCustomized(object sender, EventArgs e)
        {
            TextBox T = (TextBox)sender;

            try
            {
                //Not Allowing Numbers, Underscore or Hash
                char[] UnallowedCharacters = { '0', '1',
                                           '2', '3',
                                           '4', '5',
                                           '6', '7',
                                           '8', '9','_','#'};

                if (textContainsUnallowedCharacter(T.Text, UnallowedCharacters))
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
            }
            catch (Exception) { }
        }


        private void bttn2_Click(object sender, EventArgs e)
        {
            //for Insert// button code
            var st = new MyUseTab
            {
                UseFName = txtfname.Text,
                UseLName = txtlstname.Text,
                UseName = txtuname.Text,
                UsePassword = txtpass.Text,
                UsePhone = double.Parse(txtph.Text),
                UseCnic = txtcnic.Text,
                UserID = combo1.Text,
            };
            db.MyUseTabs.InsertOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Data Inserted");
            loaddata();
        }

        private void loaddata()
        {
            var st = from s in db.MyUseTabs select s;
            dataGridView1.DataSource = st;
        }

        private void bttn4_Click(object sender, EventArgs e)
        {
            var st = (from s in db.MyUseTabs where s.UseFName == txtfname.Text select s).First();
            db.MyUseTabs.DeleteOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Successfully Deleted...");
            loaddata();
        }

        private void NewUser_Load(object sender, EventArgs e)
        {
            ProdGV.AutoGenerateColumns = false;
            loadData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            NewCoutomer NC = new NewCoutomer();
            this.Hide();
            NC.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CashInner CI = new CashInner();
            this.Hide();
            CI.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CashOuter CO = new CashOuter();
            this.Hide();
            CO.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            NewCoutomer NC = new NewCoutomer();
            this.Hide();
            NC.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Record R = new Record();
            this.Hide();
            R.Show();
        }

        private void Insertinsqltable_Click(object sender, EventArgs e)
        {
            string userfname = "", userlname = "", username = "", userpassword = "", usercnic = "", userid = "";
            double userphone = 0;
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {


                userfname = ProdGV.Rows[i].Cells[0].Value.ToString();
                userlname = ProdGV.Rows[i].Cells[1].Value.ToString();
                username = ProdGV.Rows[i].Cells[2].Value.ToString();
                userpassword = ProdGV.Rows[i].Cells[3].Value.ToString();
                userphone = Convert.ToDouble(ProdGV.Rows[i].Cells[4].Value.ToString());
                usercnic = ProdGV.Rows[i].Cells[5].Value.ToString();
                userid = ProdGV.Rows[i].Cells[6].Value.ToString();

                var st = new MyUseTab
                {
                    UseFName = userfname,
                    UseLName = userlname,
                    UseName = username,
                    UsePassword = userpassword,
                    UsePhone = userphone,
                    UseCnic = usercnic,
                    UserID = userid,
                };
                db.MyUseTabs.InsertOnSubmit(st);
                db.SubmitChanges();
                ProdGV.Rows[i].Cells[7].Value = "Success";
                loadData();
            }
        }

        private void loadData()
        {
            var st = from s in db.MyinfoTabs select s;
            dataGridView1.DataSource = st;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Admin a_p = new Admin();
            this.Hide();
            a_p.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Index i = new Index();
            this.Close();
            i.Show();
        }
    }
}