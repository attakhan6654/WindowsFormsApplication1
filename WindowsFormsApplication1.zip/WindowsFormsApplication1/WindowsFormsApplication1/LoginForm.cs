﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True");

        DataClasses1DataContext db = new DataClasses1DataContext();
        private void button1_Click(object sender, EventArgs e)
        {
            var usertype = (from s in db.MyUserTabs
                            where s.UserType == combo1.Text && s.UserName == txtname.Text
                            select s).First();
            if (usertype.UserPassword == txtpass.Text) {
                Admin_panel a_p = new Admin_panel();
                this.Hide();
                a_p.Show();
            
            }
            else
            {
                MessageBox.Show("Password Error");


            }


            //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True"); // making connection   
            ////SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM MyUserTab WHERE UserType=" + combo1.Text + "UserName=" + txtname.Text + "And UserPassword=" + txtpass.Text, con);
            //SqlDataAdapter sda = new SqlDataAdapter("SELECT UserName =" + txtname.Text + "UserPassword="+txtpass.Text+" FROM MyUserTab WHERE UserType=" + combo1.Text.ToString(), con);
            ///* in above line the program is selecting the whole data from table and the matching it with the user name and password provided by user. */
            //DataTable dt = new DataTable(); //this is creating a virtual table  
            //sda.Fill(dt);
            //if (dt.Rows[0][0].ToString() != "0")
            //{
            //    /* I have made a new page called home page. If the user is successfully authenticated then the form will be moved to the next form */
            //    Index i = new Index();
            //    this.Hide();
            //    i.Show();
            //}
            //else
            //{
            //    MessageBox.Show("Invalid username or password");
            //}

            //con.Open();
            //SqlCommand cmd = new SqlCommand("insert into loginTbl values('" + txtname.Text + "', '" + txtpass.Text + "')", con);
            //cmd.ExecuteNonQuery();
            //MessageBox.Show("Data Inserted Successfully.");

            //string cmbitemvalue = combo1.SelectedItem.ToString();
            //SqlCommand cmdd = new SqlCommand("insert into User values('" + cmbitemvalue + "', '" + txtname.Text + "', '" + txtpass.Text + "')", con);
            ////SqlDataAdapter da = new SqlDataAdapter(cmdd);
            //DataTable dt = new DataTable();
            ////da.Fill(dt);

            //if (dt.Rows.Count > 0)
            //{
            //    for (int i = 0; i < dt.Rows.Count; i++)
            //    {
            //        if (dt.Rows[i]["usertype"].ToString() == cmbitemvalue)
            //        {
            //            MessageBox.Show("Sign Up Successfully" + dt.Rows[i][2]);
            //            if (combo1.SelectedIndex == 0)
            //            {
            //                Admin_panel ap = new Admin_panel();
            //                ap.Show();
            //                this.Hide();

            //            }
            //            else
            //            {
            //                //User us = new User();
            //                //us.Show();
            //                //this.Hide();

            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("error");
            //}


            ///*
            //con.Open();
            //SqlCommand cmdd = new SqlCommand("insert into User && User values('" + combo1.Text + "', '" + txtpass.Text + "', '" + txtpass.Text + "')", con);
            //cmdd.ExecuteNonQuery();
            //MessageBox.Show("Data Inserted Successfully.");
            //con.Close();
            //*/
            //con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //for Insert// button code
            var st = new MyUserTab
            {
                UserType = combo1.Text,
                UserName = txtname.Text,
                UserPassword = txtpass.Text,

            };
            db.MyUserTabs.InsertOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Signed Up");
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtname.Clear();
            txtpass.Clear();
        }
    }
}
