﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        string cs = ConfigurationManager.ConnectionStrings[@"Data Source=DESKTOP-KF1H18L;Initial Catalog=WINFORM_DB;Integrated Security=True"].ConnectionString;
        //string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        public Form6()
        {
            InitializeComponent();
        }
        //string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        //string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Image";
            //ofd.Filter = "PNG FILE (*.png) | *.png | JPG FILE (*.jpg) | *.jpg | BMP FILE (*.bmp) | *.bmp | GIF FILE (*.gif) | *.gif";
            //ofd.Filter = "BMP FILE (*.bmp) | *.bmp";
            //ofd.Filter = "GIF FILE (*.gif) | *.gif";
            //ofd.Filter = "JPG FILE (*.jpg) | *.jpg";
            //ofd.Filter = "PNG FILE (*.PNG) | *.PNG";
            //ofd.Filter = "PNG FILE (*.png) | *.png | JPG FILE (*.jpg) | *.jpg | BMP FILE (*.bmp) | *.bmp | GIF FILE (*.gif) | *.gif";
            //ofd.Filter = "Image File (*.png;*.jpg;*.bmp;*.gif) | *.png;*.jpg;*.bmp;*.gif";
            ofd.Filter = "Image File (*.png;*.jpg;*.bmp;*.gif) | *.png;*.jpg;*.bmp;*.gif | All files(*.*) | *.*)";
            //ofd.ShowDialog();
            if (ofd.ShowDialog() == DialogResult.OK) 
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
                
            

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "insert into student_details values(@id, @name, @age, @image)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", textBox1.Text);
            cmd.Parameters.AddWithValue("@name", textBox2.Text);
            cmd.Parameters.AddWithValue("@age", numericUpDown1.Value);
            cmd.Parameters.AddWithValue("@image", SavePhoto());
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if(a > 0)
            {
                MessageBox.Show("Data Inserted");
            }
            else
            {
                MessageBox.Show("Insertion Failed");
            }
            con.Close();

        }

        private byte[] SavePhoto()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms,pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }
    }
}
