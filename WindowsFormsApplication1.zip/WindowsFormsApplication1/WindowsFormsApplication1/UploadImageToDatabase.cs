﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication1
{
    public partial class UploadImageToDatabase : Form
    {
        public UploadImageToDatabase()
        {
            InitializeComponent();
        }

        private void UploadImageToDatabase_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet.Pictures' table. You can move, or remove it, as needed.
            this.picturesTableAdapter.Fill(this.databaseDataSet.Pictures);

        }

        public void Insert(string fileName, byte[] Image)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["WindowsFormsApplication1.Properties.Settings.DatabaseConnectionString"].ConnectionString))
            {

                if (cn.State == ConnectionState.Closed)
                    cn.Open();
                using (SqlCommand cmd = new SqlCommand("insert into pictures(filename, image values(@filename, @image) )"))
                {

                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@filename", txtFileName.Text);
                    cmd.Parameters.AddWithValue("@image", image);
                    cmd.ExecuteNonQuery();

                }
            

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
