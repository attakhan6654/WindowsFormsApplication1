﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True");
        DataClasses1DataContext db = new DataClasses1DataContext();
        //integer validations
        private void validateTextInteger(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                if (T.Text != "-")
                {
                    int x = int.Parse(T.Text);
                }
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        //double validation
        private void validateTextDouble(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                if (T.Text != "-")
                {
                    double x = double.Parse(T.Text);

                    if (T.Text.Contains(','))
                        throw X;
                }
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        //charactor validation
        private void validateTextCharacter(object sender, EventArgs e)
        {
            TextBox T = (TextBox)sender;
            try
            {
                //Not Allowing Numbers
                char[] UnallowedCharacters = { '0', '1',
                                           '2', '3',
                                           '4', '5',
                                           '6', '7',
                                           '8', '9'};

                if (textContainsUnallowedCharacter(T.Text, UnallowedCharacters))
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
            }
            catch (Exception) { }
        }

        private bool textContainsUnallowedCharacter(string T, char[] UnallowedCharacters)
        {
            for (int i = 0; i < UnallowedCharacters.Length; i++)
                if (T.Contains(UnallowedCharacters[i]))
                    return true;

            return false;
        }

        //integer customization x<0
        private void validateTextIntegerCustomized(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                int x = int.Parse(T.Text);

                //Customizing Condition
                if (x <= 0)
                    throw X;
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }

            }
        }

        //double customization x<0
        private void validateTextDoubleCustomized(object sender, EventArgs e)
        {
            Exception X = new Exception();

            TextBox T = (TextBox)sender;

            try
            {
                double x = double.Parse(T.Text);

                //Customizing Condition (Only numbers larger than or 
                //equal to zero are permitted)
                if (x < 0 || T.Text.Contains(','))
                    throw X;
            }
            catch (Exception)
            {
                try
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
                catch (Exception) { }
            }
        }

        //chractor customization
        private void validateTextCharacterCustomized(object sender, EventArgs e)
        {
            TextBox T = (TextBox)sender;

            try
            {
                //Not Allowing Numbers, Underscore or Hash
                char[] UnallowedCharacters = { '0', '1',
                                           '2', '3',
                                           '4', '5',
                                           '6', '7',
                                           '8', '9','_','#'};

                if (textContainsUnallowedCharacter(T.Text, UnallowedCharacters))
                {
                    int CursorIndex = T.SelectionStart - 1;
                    T.Text = T.Text.Remove(CursorIndex, 1);

                    //Align Cursor to same index
                    T.SelectionStart = CursorIndex;
                    T.SelectionLength = 0;
                }
            }
            catch (Exception) { }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            ////for Insert// button code
            //var st = new MyUserTab
            //{
            //    UserType = combo1.Text,
            //    UserName = txtname.Text,
            //    UserPassword = txtpass.Text,

            //};
            //db.MyUserTabs.InsertOnSubmit(st);
            //db.SubmitChanges();
            //MessageBox.Show("Signed Up");

            var st = (from s in db.MyUserTabs where /* s.UserID == combo1.Text && */ s.UserName == txtname.Text select s).First();


            st.UserPassword = txtpass.Text;
            db.MyUserTabs.InsertOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Successfully Updated");



            //con.Open();
            //SqlCommand cmd = new SqlCommand("insert into loginTbl values('" + txtname.Text + "', '" + txtpass.Text + "')", con);
            //cmd.ExecuteNonQuery();
            //MessageBox.Show("Data Inserted Successfully.");

            //string cmbitemvalue = combo1.SelectedItem.ToString();
            //SqlCommand cmdd = new SqlCommand("insert into User values('" + cmbitemvalue + "', '" + txtname.Text + "', '" + txtpass.Text + "')", con);
            ////SqlDataAdapter da = new SqlDataAdapter(cmdd);
            //DataTable dt = new DataTable();
            ////da.Fill(dt);

            //if (dt.Rows.Count > 0)
            //{
            //    for (int i = 0; i < dt.Rows.Count; i++)
            //    {
            //        if (dt.Rows[i]["usertype"].ToString() == cmbitemvalue)
            //        {
            //            MessageBox.Show("Sign Up Successfully" + dt.Rows[i][2]);
            //            if (combo1.SelectedIndex == 0)
            //            {
            //                Admin_panel ap = new Admin_panel();
            //                ap.Show();
            //                this.Hide();

            //            }
            //            else
            //            {
            //                //User us = new User();
            //                //us.Show();
            //                //this.Hide();

            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("error");
            //}


            ///*
            //con.Open();
            //SqlCommand cmdd = new SqlCommand("insert into User && User values('" + combo1.Text + "', '" + txtpass.Text + "', '" + txtpass.Text + "')", con);
            //cmdd.ExecuteNonQuery();
            //MessageBox.Show("Data Inserted Successfully.");
            //con.Close();
            //*/
            //con.Close();

        }

        private void loaddata()
        {
            throw new NotImplementedException();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var usertype = (from s in db.MyUserTabs
                            where /* s.UserID == combo1.Text && */ s.UserName == txtname.Text
                            select s).First();
            if (usertype.UserPassword == txtpass.Text)
            {
                Admin a_p = new Admin();
                this.Hide();
                a_p.Show();

            }
            else
            {
                MessageBox.Show("Password Error");


            }


            //Index i = new Index();
            //this.Hide();
            //i.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
                txtpass.UseSystemPasswordChar = true;
            else
                txtpass.UseSystemPasswordChar = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtname.Text = "";
            txtpass.Text = "";
        }
    }
}
