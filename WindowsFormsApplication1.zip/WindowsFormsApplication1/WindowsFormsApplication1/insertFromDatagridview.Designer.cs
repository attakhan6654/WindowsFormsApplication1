﻿namespace WindowsFormsApplication1
{
    partial class insertFromDatagridview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Insertinsqltable = new System.Windows.Forms.Button();
            this.updateinsqltable = new System.Windows.Forms.Button();
            this.txtcusno = new System.Windows.Forms.TextBox();
            this.txtcusid = new System.Windows.Forms.TextBox();
            this.txtcusname = new System.Windows.Forms.TextBox();
            this.txtcusaddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.abcDataSet = new WindowsFormsApplication1.abcDataSet();
            this.myCusTabBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myCusTabTableAdapter = new WindowsFormsApplication1.abcDataSetTableAdapters.MyCusTabTableAdapter();
            this.chk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cusIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cusNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cusAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cusPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abcDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCusTabBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(419, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(342, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "insert From Data grid view";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Name,
            this.Address,
            this.Age,
            this.msg});
            this.dataGridView1.Location = new System.Drawing.Point(150, 378);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(614, 161);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.MinimumWidth = 8;
            this.ID.Name = "ID";
            this.ID.Width = 150;
            // 
            // Name
            // 
            this.Name.HeaderText = "UName";
            this.Name.MinimumWidth = 8;
            this.Name.Name = "Name";
            this.Name.Width = 110;
            // 
            // Address
            // 
            this.Address.HeaderText = "Address";
            this.Address.MinimumWidth = 8;
            this.Address.Name = "Address";
            this.Address.Width = 180;
            // 
            // Age
            // 
            this.Age.HeaderText = "Age";
            this.Age.MinimumWidth = 8;
            this.Age.Name = "Age";
            this.Age.Width = 80;
            // 
            // msg
            // 
            this.msg.HeaderText = "msg";
            this.msg.MinimumWidth = 8;
            this.msg.Name = "msg";
            this.msg.ReadOnly = true;
            this.msg.Width = 150;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chk,
            this.cusIDDataGridViewTextBoxColumn,
            this.cusNameDataGridViewTextBoxColumn,
            this.cusAddressDataGridViewTextBoxColumn,
            this.cusPhoneDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.myCusTabBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(149, 546);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(612, 133);
            this.dataGridView2.TabIndex = 2;
            // 
            // Insertinsqltable
            // 
            this.Insertinsqltable.Location = new System.Drawing.Point(12, 370);
            this.Insertinsqltable.Name = "Insertinsqltable";
            this.Insertinsqltable.Size = new System.Drawing.Size(111, 133);
            this.Insertinsqltable.TabIndex = 3;
            this.Insertinsqltable.Text = "Insert in sql table";
            this.Insertinsqltable.UseVisualStyleBackColor = true;
            this.Insertinsqltable.Click += new System.EventHandler(this.Insertinsqltable_Click);
            // 
            // updateinsqltable
            // 
            this.updateinsqltable.Location = new System.Drawing.Point(12, 546);
            this.updateinsqltable.Name = "updateinsqltable";
            this.updateinsqltable.Size = new System.Drawing.Size(111, 133);
            this.updateinsqltable.TabIndex = 4;
            this.updateinsqltable.Text = "Update in sql table";
            this.updateinsqltable.UseVisualStyleBackColor = true;
            this.updateinsqltable.Click += new System.EventHandler(this.updateinsqltable_Click);
            // 
            // txtcusno
            // 
            this.txtcusno.BackColor = System.Drawing.Color.Gainsboro;
            this.txtcusno.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcusno.ForeColor = System.Drawing.Color.MediumBlue;
            this.txtcusno.Location = new System.Drawing.Point(592, 332);
            this.txtcusno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcusno.Name = "txtcusno";
            this.txtcusno.Size = new System.Drawing.Size(172, 32);
            this.txtcusno.TabIndex = 118;
            // 
            // txtcusid
            // 
            this.txtcusid.BackColor = System.Drawing.Color.Gainsboro;
            this.txtcusid.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcusid.ForeColor = System.Drawing.Color.MediumBlue;
            this.txtcusid.Location = new System.Drawing.Point(592, 63);
            this.txtcusid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcusid.Name = "txtcusid";
            this.txtcusid.Size = new System.Drawing.Size(172, 32);
            this.txtcusid.TabIndex = 116;
            // 
            // txtcusname
            // 
            this.txtcusname.BackColor = System.Drawing.Color.Gainsboro;
            this.txtcusname.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcusname.ForeColor = System.Drawing.Color.MediumBlue;
            this.txtcusname.Location = new System.Drawing.Point(592, 147);
            this.txtcusname.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcusname.Name = "txtcusname";
            this.txtcusname.Size = new System.Drawing.Size(172, 32);
            this.txtcusname.TabIndex = 117;
            // 
            // txtcusaddress
            // 
            this.txtcusaddress.BackColor = System.Drawing.Color.Gainsboro;
            this.txtcusaddress.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcusaddress.ForeColor = System.Drawing.Color.MediumBlue;
            this.txtcusaddress.Location = new System.Drawing.Point(592, 250);
            this.txtcusaddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcusaddress.Name = "txtcusaddress";
            this.txtcusaddress.Size = new System.Drawing.Size(172, 32);
            this.txtcusaddress.TabIndex = 119;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Tomato;
            this.label2.Location = new System.Drawing.Point(358, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 31);
            this.label2.TabIndex = 120;
            this.label2.Text = "Customer Id:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Tomato;
            this.label5.Location = new System.Drawing.Point(362, 344);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 31);
            this.label5.TabIndex = 121;
            this.label5.Text = "Phone#:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Tomato;
            this.label6.Location = new System.Drawing.Point(358, 157);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(209, 31);
            this.label6.TabIndex = 122;
            this.label6.Text = "Customer Name:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Tomato;
            this.label8.Location = new System.Drawing.Point(362, 262);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 31);
            this.label8.TabIndex = 123;
            this.label8.Text = "Address:";
            // 
            // abcDataSet
            // 
            this.abcDataSet.DataSetName = "abcDataSet";
            this.abcDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // myCusTabBindingSource
            // 
            this.myCusTabBindingSource.DataMember = "MyCusTab";
            this.myCusTabBindingSource.DataSource = this.abcDataSet;
            // 
            // myCusTabTableAdapter
            // 
            this.myCusTabTableAdapter.ClearBeforeFill = true;
            // 
            // chk
            // 
            this.chk.DataPropertyName = "CusID";
            this.chk.HeaderText = "chk";
            this.chk.MinimumWidth = 8;
            this.chk.Name = "chk";
            this.chk.Width = 70;
            // 
            // cusIDDataGridViewTextBoxColumn
            // 
            this.cusIDDataGridViewTextBoxColumn.DataPropertyName = "CusID";
            this.cusIDDataGridViewTextBoxColumn.HeaderText = "CusID";
            this.cusIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cusIDDataGridViewTextBoxColumn.Name = "cusIDDataGridViewTextBoxColumn";
            // 
            // cusNameDataGridViewTextBoxColumn
            // 
            this.cusNameDataGridViewTextBoxColumn.DataPropertyName = "CusName";
            this.cusNameDataGridViewTextBoxColumn.HeaderText = "CusName";
            this.cusNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cusNameDataGridViewTextBoxColumn.Name = "cusNameDataGridViewTextBoxColumn";
            this.cusNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // cusAddressDataGridViewTextBoxColumn
            // 
            this.cusAddressDataGridViewTextBoxColumn.DataPropertyName = "CusAddress";
            this.cusAddressDataGridViewTextBoxColumn.HeaderText = "CusAddress";
            this.cusAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cusAddressDataGridViewTextBoxColumn.Name = "cusAddressDataGridViewTextBoxColumn";
            this.cusAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // cusPhoneDataGridViewTextBoxColumn
            // 
            this.cusPhoneDataGridViewTextBoxColumn.DataPropertyName = "CusPhone";
            this.cusPhoneDataGridViewTextBoxColumn.HeaderText = "CusPhone";
            this.cusPhoneDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cusPhoneDataGridViewTextBoxColumn.Name = "cusPhoneDataGridViewTextBoxColumn";
            this.cusPhoneDataGridViewTextBoxColumn.Width = 150;
            // 
            // insertFromDatagridview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(904, 716);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtcusno);
            this.Controls.Add(this.txtcusid);
            this.Controls.Add(this.txtcusname);
            this.Controls.Add(this.txtcusaddress);
            this.Controls.Add(this.updateinsqltable);
            this.Controls.Add(this.Insertinsqltable);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
           //this.Name = "insertFromDatagridview";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "insertFormDatagridview";
            this.Load += new System.EventHandler(this.insertFromDatagridview_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abcDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myCusTabBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button Insertinsqltable;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Age;
        private System.Windows.Forms.DataGridViewTextBoxColumn msg;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.Button updateinsqltable;
        private System.Windows.Forms.TextBox txtcusno;
        private System.Windows.Forms.TextBox txtcusid;
        private System.Windows.Forms.TextBox txtcusname;
        private System.Windows.Forms.TextBox txtcusaddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private abcDataSet abcDataSet;
        private System.Windows.Forms.BindingSource myCusTabBindingSource;
        private abcDataSetTableAdapters.MyCusTabTableAdapter myCusTabTableAdapter;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chk;
        private System.Windows.Forms.DataGridViewTextBoxColumn cusIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cusNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cusAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cusPhoneDataGridViewTextBoxColumn;
    }
}