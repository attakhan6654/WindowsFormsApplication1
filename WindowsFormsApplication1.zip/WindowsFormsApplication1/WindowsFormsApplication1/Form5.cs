﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private byte[] ImageToByteArray(Image imageIn) {

            using (MemoryStream ms = new MemoryStream()) 
            {
                imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
                return ms.ToArray();
                
            }
        
        }

        DataClasses1DataContext db = new DataClasses1DataContext();
        private void button1_Click(object sender, EventArgs e)
        {
            byte[] file_byte = ImageToByteArray(pictureBox1.Image);
            System.Data.Linq.Binary file_binary = new System.Data.Linq.Binary(file_byte);
            var st = new Table
            {

                Name = textBox1.Text,
                UserPic = file_binary,
            };
            db.Tables.InsertOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Successfully Inserted");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            PictureBox p = sender as PictureBox;
            if (p != null)
            {
                open.Filter = "(*.jpg;*.jpg;*.pmp) | *.jpg; *jpeg; *.bmp";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    p.Image = Image.FromFile(open.FileName);
                    //MessageBox.Show(open.FileName);

                }
            }
        }

        public Image ByteArrayToImage(byte[] byteArrayIn) {

            using (MemoryStream ms = new MemoryStream(byteArrayIn))
            {
                Image returnImage = Image.FromStream(ms);
                return returnImage;
            


            }
        
        }



        private void button2_Click(object sender, EventArgs e)
        {
            var st = (from s in db.Tables where s.Name == textBox1.Text select s).First();
            pictureBox1.Image = ByteArrayToImage(st.UserPic.ToArray());

        }
    }
}
