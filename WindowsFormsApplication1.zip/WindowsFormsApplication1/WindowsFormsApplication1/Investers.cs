﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Investers : Form
    {
        public Investers()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True");
        DataClasses1DataContext db = new DataClasses1DataContext();
        private void bttn2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MyInvTab values('" + txtsupid.Text + "', '" + txtsupname.Text + "', '" + txtsupno.Text + "', '" + txtcmpname.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Inserted Successfully.");
            con.Close();
        }

        private void bttn3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KF1H18L;Initial Catalog=abc;Integrated Security=True");
            con.Open();
            if (txtsupid.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Select InvName, InvCompany, InvPhone from MyInvTab where InvID=@InvID", con);
                cmd.Parameters.AddWithValue("@InvID", int.Parse(txtsupid.Text));
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    txtsupname.Text = da.GetValue(0).ToString();
                    txtcmpname.Text = da.GetValue(1).ToString();
                    txtsupno.Text = da.GetValue(2).ToString();
                }
            }
            con.Close();
        }

        private void bttn4_Click(object sender, EventArgs e)
        {
            var st = (from s in db.MyInvTabs where s.InvID == int.Parse(txtsupid.Text) select s).First();
            db.MyInvTabs.DeleteOnSubmit(st);
            db.SubmitChanges();
            MessageBox.Show("Successfully Deleted...");
            loaddata();
        }

        private void loaddata()
        {
            throw new NotImplementedException();
        }

        private void Insertinsqltable_Click(object sender, EventArgs e)
        {
            int iid = 0; string iname = "", icompany = ""; double iphone = 0;
            for (int i = 0; i < ProdGV.Rows.Count - 1; i++)
            {

                iid = Convert.ToInt32(ProdGV.Rows[i].Cells[0].Value.ToString());
                iname = ProdGV.Rows[i].Cells[1].Value.ToString();
                icompany = ProdGV.Rows[i].Cells[2].Value.ToString();
                iphone = Convert.ToDouble(ProdGV.Rows[i].Cells[3].Value.ToString());

                var st = new MyInvTab
                {
                    InvID = iid,
                    InvName = iname,
                    InvCompany = icompany,
                    InvPhone = iphone,
                };
                db.MyInvTabs.InsertOnSubmit(st);
                db.SubmitChanges();
                ProdGV.Rows[i].Cells[4].Value = "Success";
                loadData();
            }
        }

        private void loadData()
        {
            var st = from s in db.MyInvTabs select s;
            dataGridView1.DataSource = st;
        }

        private void Investers_Load(object sender, EventArgs e)
        {
            ProdGV.AutoGenerateColumns = false;
            loadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CashOuter CO = new CashOuter();
            this.Hide();
            CO.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            NewCoutomer NC = new NewCoutomer();
            this.Hide();
            NC.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            NewCoutomer NC = new NewCoutomer();
            this.Hide();
            NC.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Record R = new Record();
            this.Hide();
            R.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Admin_panel a_p = new Admin_panel();
            this.Hide();
            a_p.Show();
        }
    }
}
