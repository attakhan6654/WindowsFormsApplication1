﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Record : Form
    {
        public Record()
        {
            InitializeComponent();
        }
        DataClasses1DataContext db = new DataClasses1DataContext();
        private void button9_Click(object sender, EventArgs e)
        {
            loaddatanu();
        }

        private void loaddatanu()
        {
            var st = from s in db.MyUseTabs select s;
            dataGridView1.DataSource = st;
        }

        private void loaddataco()
        {
            var st = from s in db.CashOuts select s;
            dataGridView3.DataSource = st;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            loaddataci();
        }

        private void loaddataci()
        {
            var st = from s in db.CashIns select s;
            dataGridView1.DataSource = st;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            loaddataco();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            loaddatar();
        }

        private void loaddatar()
        {
            var st = from s in db.CashIns select s;
            dataGridView5.DataSource = st;
            var stt = from s in db.CashOuts select s;
            dataGridView5.DataSource = stt;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Admin a_p = new Admin();
            this.Hide();
            a_p.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            loaddatanc();
        }

        private void loaddatanc()
        {
            var st = from s in db.MyCusTabs select s;
            dataGridView4.DataSource = st;
        }
    }
}
