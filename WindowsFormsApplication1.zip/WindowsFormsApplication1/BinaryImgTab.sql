﻿CREATE TABLE [dbo].[Table]
(
	[Name] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [UserPic] IMAGE NULL
)